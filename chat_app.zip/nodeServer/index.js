const io = require('socket.io')(8000, {
    cors: {
      origin: "*",
    }
  });
  const users = {};
  
  io.on('connection', socket => {
    console.log('New connection:', socket.id);
  
    socket.on('new-user-joined', newname => {
      console.log("New user:", newname);
      users[socket.id] = newname;
      socket.broadcast.emit('user-joined', newname);
    });
  
    socket.on('send', message => {
      socket.broadcast.emit('receive', { message: message, newname: users[socket.id] });
    });
  
    socket.on('disconnect', () => {
      socket.broadcast.emit('user-left', users[socket.id]);
      delete users[socket.id];
    });
  });
  