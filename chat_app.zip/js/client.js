const socket = io('http://localhost:8000');

const form = document.getElementById('send-container');
const messageInput = document.getElementById('messageInp');
const messageContainer = document.querySelector('.container');

const append = (message, position) => {
  const messageElement = document.createElement('div');
  messageElement.innerText = message;
  messageElement.classList.add('message');
  messageElement.classList.add(position);
  messageContainer.append(messageElement);
  messageContainer.scrollTop = messageContainer.scrollHeight;
  var audio = new Audio('ring.mp3');


  if (position == 'left') {
    audio.play();
  }
  
};

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const message = messageInput.value;
  if (message.trim() !== '') {
    append(`You: ${message}`, 'right');
    socket.emit('send', message);
    messageInput.value = '';
  }
});

let userName = prompt('Enter your name to join');
if (!userName || userName.trim() === '') {
  userName = 'Anonymous';
}
socket.emit('new-user-joined', userName);

socket.on('user-joined', (name) => {
  var audiojoin = new Audio('ting.mp3');
  append(`${name} joined the chat`, 'right');
  audiojoin.play();
});

socket.on('receive', (data) => {
  append(`${data.newname}: ${data.message}`, 'left');
});

socket.on('user-left', (name) => {
  append(`${name} left the chat`, 'left');
});

socket.on('connect_error', (err) => {
  append('Failed to connect to the server.', 'center');
  console.error('Connection error:', err);
});
